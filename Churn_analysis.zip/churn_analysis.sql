use prjct;
select * from telecom_churn;

select churn,(count(churn)/(select count(*) from telecom_churn))*100 as churn_flag_count 
from telecom_churn group by churn;

select gender,(count(gender)/(select count(*) from telecom_churn))*100 as gender_perc
from telecom_churn group by gender;
select gender,churn,(count(gender)/(select count(*) from telecom_churn))*100 as gender_perc
from telecom_churn group by gender,churn;

select partner,(count(partner)/(select count(*) from telecom_churn))*100 as partner_perc
from telecom_churn group by partner;
select partner,churn,(count(partner)/(select count(*) from telecom_churn))*100 as partner_perc
from telecom_churn group by partner,churn;

select dependents,(count(dependents)/(select count(*) from telecom_churn))*100 as dependent_perc
from telecom_churn group by dependents;
select dependents,churn,(count(dependents)/(select count(*) from telecom_churn))*100 as dependent_perc
from telecom_churn group by dependents,churn;

select phoneservice,(count(phoneservice)/(select count(*) from telecom_churn))*100 as phoneservice_perc 
from telecom_churn group by phoneservice;
select phoneservice,churn,(count(phoneservice)/(select count(*) from telecom_churn))*100 as phoneservice_perc 
from telecom_churn group by phoneservice,churn;


select seniorcitizen,(count(seniorcitizen)/(select count(*) from telecom_churn))*100 as seniorcitizen_perc
from telecom_churn group by seniorcitizen;
select seniorcitizen,churn,(count(seniorcitizen)/(select count(*) from telecom_churn))*100 as seniorcitizen_perc
from telecom_churn group by seniorcitizen,churn;

select multiplelines,(count(multiplelines)/(select count(*) from telecom_churn))*100 as multipleline 
from telecom_churn group by multiplelines;
select multiplelines,churn,(count(multiplelines)/(select count(*) from telecom_churn))*100 as multipleline 
from telecom_churn group by multiplelines,churn;

select internetservice,(count(internetservice)/(select count(*) from telecom_churn))*100 as internetservice_perc 
from telecom_churn group by internetservice;
select internetservice,churn,(count(internetservice)/(select count(*) from telecom_churn))*100 as internetservice_perc 
from telecom_churn group by internetservice,churn;

select onlinesecurity,(count(onlinesecurity)/(select count(*) from telecom_churn))*100 as onlinesecurity_perc 
from telecom_churn group by onlinesecurity;
select onlinesecurity,churn,(count(onlinesecurity)/(select count(*) from telecom_churn))*100 as onlinesecurity_perc 
from telecom_churn group by onlinesecurity,churn;

select onlinebackup,(count(onlinebackup)/(select count(*) from telecom_churn))*100 as onlinebackuop_perc 
from telecom_churn group by onlinebackup;
select onlinebackup,churn,(count(onlinebackup)/(select count(*) from telecom_churn))*100 as onlinebackuop_perc 
from telecom_churn group by onlinebackup,churn;

select deviceprotection,(count(deviceprotection)/(select count(*) from telecom_churn))*100 as deviceprotection
from telecom_churn group by deviceprotection;
select deviceprotection,churn,(count(deviceprotection)/(select count(*) from telecom_churn))*100 as deviceprotection
from telecom_churn group by deviceprotection,churn;

select techsupport,(count(techsupport)/(select count(*) from telecom_churn))*100 as techsupport_perc 
from telecom_churn group by techsupport;
select techsupport,churn,(count(techsupport)/(select count(*) from telecom_churn))*100 as techsupport_perc 
from telecom_churn group by techsupport,churn;

select streamingtv,(count(streamingtv)/(select count(*) from telecom_churn))*100 as streamingtv_perc 
from telecom_churn group by streamingtv;
select streamingtv,churn,(count(streamingtv)/(select count(*) from telecom_churn))*100 as streamingtv_perc 
from telecom_churn group by streamingtv,churn;

select streamingmovies,(count(streamingmovies)/(select count(*) from telecom_churn))*100 as streaming_movies_perc
from telecom_churn group by streamingmovies;
select streamingmovies,churn,(count(streamingmovies)/(select count(*) from telecom_churn))*100 as streaming_movies_perc
from telecom_churn group by streamingmovies,churn;

select contract,churn,(count(contract)/(select count(*) from telecom_churn))*100 as contract_perc 
from telecom_churn group by contract,churn;

select paperlessbilling,(count(churn)/(select count(*) from telecom_churn))*100 as lessbilling_perc 
from telecom_churn group by paperlessbilling;
select paperlessbilling,churn,(count(churn)/(select count(*) from telecom_churn))*100 as lessbilling_perc 
from telecom_churn group by paperlessbilling,churn;

select * from telecom_churn;